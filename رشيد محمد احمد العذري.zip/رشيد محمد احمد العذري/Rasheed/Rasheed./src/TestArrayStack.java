

import java.util.Scanner;

public class TestArrayStack {
    public static void main(String[] args) {
        ArrayOfStack<Integer> s = new ArrayOfStack<>(5);
        Scanner in = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            s.push(in.nextInt());
            System.out.println("The top is "+ s.top());
            System.out.println("The size is "+ s.size());
        }
    }
}
