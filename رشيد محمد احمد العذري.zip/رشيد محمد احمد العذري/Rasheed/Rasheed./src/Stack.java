public interface Stack<T>{
    boolean isEmpty();
   void push(T t);
   T pop();
   T top();
   int size();

}
